/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkgnew;

import javax.swing.JOptionPane;

/**
 *
 * @author mphok
 */
public class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
    
    private static int counter = 0;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = counter++;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
        this.taskStatus = taskStatus;
    }
        public boolean checkTaskDescription() {
                return taskDescription.length() <= 50;
    }
    public void printTaskDetails() {
        String details = "Task Status: " + taskStatus +
                         "\nDeveloper Details: " + developerDetails +
                         "\nTask Number: " + taskNumber +
                         "\nTask Name: " + taskName +
                         "\nTask Description: " + taskDescription +
                         "\nTask ID: " + taskID +
                         "\nTask Duration: " + taskDuration + " hrs";

        JOptionPane.showMessageDialog(null, details);
    }
    
    private String createTaskID() {
        String taskNamePrefix = taskName.substring(0, 2).toUpperCase();
        String developerLastNameSuffix = developerDetails.substring(developerDetails.lastIndexOf(" ") + 1).toUpperCase();
        
        return taskNamePrefix + ":" + taskNumber + ":" + developerLastNameSuffix;
    }
    
     public static int returnTotalHours(Task[] tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.taskDuration;
        }
        return totalHours;
    }
    
       // Getters and Setters

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public void setTaskNumber(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public String getDeveloperDetails() {
        return developerDetails;
    }

    public void setDeveloperDetails(String developerDetails) {
        this.developerDetails = developerDetails;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public void setTaskDuration(int taskDuration) {
        this.taskDuration = taskDuration;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }
}


