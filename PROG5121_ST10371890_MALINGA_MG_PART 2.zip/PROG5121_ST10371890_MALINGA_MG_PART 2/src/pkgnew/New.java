/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgnew;
 import javax.swing.JOptionPane;
/**
 *
 * @author mphok
 */
public class New {
    private StringBuilder hold = new StringBuilder();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
           
        String expectedUsername = "ST10371890";
        String expectedPassword = "P@55word";

        boolean loggedIn = false;
        int attempts = 3;

        do {
            String username = JOptionPane.showInputDialog("Enter your username:");
            String password = JOptionPane.showInputDialog("Enter your password:");

            if (username.equals(expectedUsername) && password.equals(expectedPassword)) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                loggedIn = true;
                JOptionPane.showMessageDialog(null, "Welcome to EasyKanban!");
            } else {
                attempts--;
                JOptionPane.showMessageDialog(null, "Login failed. You have " + attempts + " attempts remaining.");
            }
        } while (!loggedIn && attempts > 0);

        if (!loggedIn) {
            JOptionPane.showMessageDialog(null, "Login failed. No more attempts remaining. Exiting program.");
        }
        
        New luda = new New();
        New.menuOption();
                     
                               
    }                              
     public static void menuOption() {
         
        int option = Integer.parseInt(JOptionPane.showInputDialog(null, "1: Add task\n"
                                                                                         + "2: Show report \n"
                                                                                             + "3: Quit"));

            switch (option) {
                case 1:
                    addTasks();
                    break;
                case 2:
                  JOptionPane.showMessageDialog(null, "Coming soon");
                    break;
                case 3:
                     JOptionPane.showMessageDialog(null, "Are you sure you want to Quit");
                    break;
                default:
                    break;
            }
        } 
        
        
    

       

    public static void addTasks() {
        // Add your logic for adding tasks here
        
int number = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks to capture"));

        for (int c = 0; c < number; c++) {
            String task_name = JOptionPane.showInputDialog(null, "Enter task name");
            JOptionPane.showMessageDialog(null, "Task number " + (c + 1));
            String task_number = "" + (c + 1);
            String task_description = JOptionPane.showInputDialog(null, "Enter task description");

            if (task_description.length() <= 50) {
                JOptionPane.showMessageDialog(null, "Task successfully captured", "Task Description", JOptionPane.PLAIN_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Enter your task description with less than 50 characters", "Task Description warning", JOptionPane.ERROR_MESSAGE);
            }

            String deve_details = JOptionPane.showInputDialog(null, "Enter Both Name And Surname", "Developer Details",JOptionPane.PLAIN_MESSAGE);

            int task_duration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration"));
             JOptionPane.showMessageDialog(null, "Task ID" + (c + 1));
                    String task_id = "" + (c + 1);
                    
             JOptionPane.showInputDialog(null, "1:To Do, 2: Done, 3: Doing", "Task Status", JOptionPane.PLAIN_MESSAGE);

             printTaskDetails("Task Status", deve_details, task_number, task_name, task_description, task_id, task_duration);
        }
    }
    public static void printTaskDetails(String taskStatus, String developerDetails, String taskNumber, String taskName, String taskDescription, String taskID, int taskDuration) {
        String details = "Task Status: " + taskStatus +
                         "\nDeveloper Details: " + developerDetails +
                         "\nTask Number: " + taskNumber +
                         "\nTask Name: " + taskName +
                         "\nTask Description: " + taskDescription +
                         "\nTask ID: " + taskID +
                         "\nTask Duration: " + taskDuration + " hrs";

        JOptionPane.showMessageDialog(null, details);
    }
}

   





  



   


   
   
        
    

    

